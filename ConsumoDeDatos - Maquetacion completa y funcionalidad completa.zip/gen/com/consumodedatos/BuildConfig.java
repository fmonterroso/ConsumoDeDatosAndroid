/** Automatically generated file. DO NOT MODIFY */
package com.consumodedatos;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}