package com.consumodedatos;

import java.util.ArrayList;

public final class Configuracion {
	public static Principal context = null;
	public static ArrayList<String[]> list = new ArrayList();
	public static ArrayList<String> blacklist = new ArrayList();
	
}
